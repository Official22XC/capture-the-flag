<?php
// Password Ada Di dalam gambar.
   echo "\nPassword => ";
   $pass = trim(fgets(STDIN));
   $ambil = file_get_contents("pass.txt"); // [JHEAD OPTION]
   if(password_verify($pass, $ambil)){
   echo "\n======================================================";
   echo "\nSelamat Anda Berhasil Menyelesaikan CTF 22XploiterCrew";
   echo "\n======================================================\n\n";
   }else{
   	echo "\nSystem Error\n\n";
   }
?>
