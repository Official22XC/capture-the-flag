Only Terminal Gayn.
cluenya cuma decode:)
ez kok sayang
